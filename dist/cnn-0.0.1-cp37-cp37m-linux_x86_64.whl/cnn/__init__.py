from .dense import NN
from .data import preprocess_data